#ifndef __BT_MESH_MEDIA_BROADCAST_DEMO_H__
#define __BT_MESH_MEDIA_BROADCAST_DEMO_H__

void amebacam_broadcast_demo_init_thread(void);

#endif //#ifndef __MEDIA_AMEBACAM_BROADCAST_DEMO_H__

