/**
*****************************************************************************************
*     Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file     bt_mesh_provisioner_ces_demo.
  * @brief    Source file for ces demo.
  * @details  
  * @author   sherman
  * @date     2021-10-20
  * @version  v1.0
  * *************************************************************************************
  */

#ifndef _BT_MESH_PROVISIONER_CES_DEMO_H_
#define _BT_MESH_PROVISIONER_CES_DEMO_H_

void example_bt_mesh(void);

#endif /* _BT_MESH_PROVISIONER_CES_DEMO_H_ */

