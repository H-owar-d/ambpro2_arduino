#ifndef QRCODE_DRV_H
#define QRCODE_DRV_H

extern char *result_string1;
extern unsigned int result_length1;

void qr_code_scanning(void);
void copyresultstring(void);

#endif /* _EXAMPLE_QR_CODE_SCANNER_H_ */
